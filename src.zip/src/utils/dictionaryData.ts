/**
 * A highly curated list of core English words.
 * This is split and loaded at runtime into the CORE_LEXICON dictionary with dynamic rank weights,
 * avoiding typescript duplicate-key syntax limitations while keeping the catalog comprehensive.
 */
const WORD_CATALOG = `
the be to of and a in that have i it for not on with he as you do at this but his by from they we say her she
or an will my one all would there their what so up out if about who get which go me when make can like time no
just him know take people into year your good some could them see other than then now look only come its over
think also back after use two how our work first well way even new want because any these give day most us
about above accept according account across act action activity actually add address administration admit affect
afford afraid afternoon again against age agency agent ago agree agreement ahead air allow almost alone along
already also although always American among amount analysis analyst analyze animal another answer anyone
anything anyway anywhere appear apply approach area argue arm army around arrive art article artist assume
attack attention attorney audience author authority available avoid away baby bad bag ball bank bar base
beautiful beauty become bed before begin behavior behind believe benefit best better between beyond big bill
billion bit black blood blue board body book born both box boy break bring brother budget build building
business buy call camera campaign cancer candidate capital car card care career carry case catch cause cell
center central century certain certainly chair challenge chance change character charge check chemical chest
chief child choice choose church citizen city civil claim class clear clearly close coach cold collection
college color comment commercial committee common community company compare comparison compete competition
complete completely complex computer concern condition conference congress consider consumer contain continue
contract control conversation cop copy corner correct correctly cost country couple course court cover create
creative crime cultural culture cup current currently customer cut dark data database daughter dead deal dear
death debate decade decide decision deep defense degree democrat democratic describe description design designer
despite detail determine develop developer development device dialogue die difference different difficult
difficulty digital dinner direction director discover discuss discussion disease distance doc doctor document
dog door down draw dream drive drop drug during each early east easy easily eat economic economy edge editor
education effect effort eight either election electric element else employee empty end energy engine engineer
enjoy enough enter enterprise environment environmental environments environmentally environmentalist error
especially establish even evening event ever every everybody everyone everything everywhere evidence exact
exactly example excellent except executive exist existence expect experience expert explain explanation
explore express extension external eye face fact factor fail failure fall family far fast father fear federal
feel feeling few field fight figure file fill film final finally financial find fine finger finish fire firm
first fish five floor fly focus folk follow following food foot force foreign forget form former forward
four free frequency friend friendly front frontend full fully function functional fund future game garden gas
general generation gentle German girl glass goal gold government grammar grammarly grammatical great green
ground group grow growth guard guess guy hair half hand hang happen happy hard head health hear heart heat
heavy hello help helpful high highly history hit hold home hope hospital hot hotel hour house hover how
huge human humble hundred husband idea identify ignore image imagine impact implement implementation important
improve improvement include indeed index indicate individual industry inflection influence information initial
input inside install installation instant instantly instead institution integration intelligent intend intent
interactive interest interesting interface internal into introduce invent invite involve issue item its
itself job join judge judgment jump just keep key kid kill kind king kitchen know knowledge land landscape
language large last late latter laugh launch law lawyer lay lead leader learn least leave left leg legal
less let letter level levenshtein lexicon library lie life light lightweight like likely limit limitation
line link list listen literal literally little live local location lock log logical look lose loss lost
lot love low machine magazine main maintain major majority manage manager management mandate manual many
map margin mark marker market marketing match matching matrix matter may maybe mean meaning meaningful
measure media medical meet meeting member memory mention menu message metal method metric middle might
military million mind mindfulness minimal minimalist minimum minute miss missing mistake model modern modify
module money month mood more morning most mother motion mouth move movement movie much multiplayer
multi_edit_file music must myself name nation national natural nature near nearest nearly neat necessary
need negative neighborhood neither network never new news next nice night nine no nobody node noise non
none nor north note nothing notice noun now number numerical obvious obviously occur occurrence off offer
office officer official offline often oh oil ok okay old once one ongoing online only onto open operate
operation opinion opportunity option or order organization organize organizer original originalWord other
others our out outcome outer outline output over overlay own owner package padding page pain paint pair
pairing paper parallel parent part participant particular particularly partner party pass passive past path
pattern pay peace penny people perfect perfectly perform performance performance_rating period periodic
permission person personal phrase physical physics pick picture piece place placeholder plan planet planner
play player playful playground pleasant please pleasure plenty plural plus pocket point police policy
political politics pool poor popular populate population port position positive possible power powered
practical practice precise precision prefer preference prefix prepare presence present president press pressure
pretty prevent previous price primary print prior prioritize pristine private probably problem process
produce product production professional program programmatic programmatically progress project prominent
pronoun proof proper properly property proposal propose protect protection protocol proud prove provide
public punctuation purchase pure purple purpose purposeful push put quality query question quick quickly
quiet quite quote race radio rail raise range rank ranking rapid rate rating ratio raw reach react read
readability readable reader reading ready real reality realize really reason rebuild recall receive recent
recently recognize recommend recommended record recursive red reduce refer reference reflect regional
regular regulation rein reinforce reject relate relational relationship relative release relevant reliance
relief religion remain remark remember remind reminder remote remove rename render repeat repeated replace
report representation represent request require required requirement research researcher reset resize
resolution resolve resource respect respond response responsibility responsible rest restaurant restore
restrict restriction result retain retrieve retro return reveal revenue review reviewer rewrite rhythm rich
rid ride right ring ripple rise risk road roadmap robust rock role roll room root row rude rule run running
runtime safe safety sale same sample sat satisfy save saw say scale scannable scan scenario scene schedule
school science scientific scientist scope score screen script sea search season seat second secondary secret
section sector secure security see seed seek seem select selection self sell send sender sense sensitive
sentence separate separation sequence serene series serious serve server service session set setting setup
seven several severe severity sex shake share shared she sheet shelf shell shift shine ship shirt shoe
shoot shop short should shoulder show side sidebar sight sign signal signature significance significant
silent silver similar simple simply simulate simulated single site situation six size skill skin skip sky
slate sleep sleek slide slight slightly slip slogan slop slow small smart smile smooth snap social society
soft software solar sold soldier sole solid solution solve solving some somebody someone something sometimes
son song soon sorry sort sound source south space spacing Spain span speak special specialist specialized
specific specify dynamic speech speed spell spelling spend spent split spoken sport spot spread spring
square stability stabilize staff stage stair stamp stand standard star start state statement static
statistics stats status stay steady steal step stick still stock stone stop storage store storm story
straight strange strategy streak stream streaming weekly weigh weight weird welcome well went west western
wet what whatever wheel when whenever where whereas whereby wherein wherever whether which while whisper
white who whoever whole whom whose why wide widely widespread wife wild will willing win wind window wine
wing winner winter wipe wire wisdom wise wish with withdraw within without witness woman wonder wonderful
wood wooden word work worker working workplace world worry worse worst worth would wound wrap wrapper
write writer writing written wrong wrote yard yeah year yellow yes yesterday yet yield you young your
yours yourself youth zone zoo
`;

// Helper to convert catalog into frequency map
function loadCoreLexicon(): { [word: string]: number } {
  const lexicon: { [word: string]: number } = {};
  const words = WORD_CATALOG.trim().toLowerCase().split(/\s+/);
  
  let index = 0;
  for (const w of words) {
    if (!w) continue;
    // Calculate a descending frequency score based on word commonality rank
    // (earlier words in our list are more common, thus higher frequency)
    const freq = Math.max(5, Math.round(100 - (index * 0.05)));
    lexicon[w] = freq;
    index++;
  }
  
  return lexicon;
}

export const CORE_LEXICON = loadCoreLexicon();

/**
 * Programmatically expands the core lexicon using regular English inflection rules.
 * This yields tens of thousands of valid English words (past tense, plurals, adverbs, gerunds, etc.)
 */
export function expandLexicon(core: { [word: string]: number }): { [word: string]: number } {
  const expanded: { [word: string]: number } = { ...core };

  // Rule helper: Add inflected word with scaled down frequency (inflections are slightly rarer than root)
  const add = (root: string, inflected: string, freqScale = 0.8) => {
    const rootFreq = core[root] || 5;
    const currentMax = expanded[inflected] || 0;
    expanded[inflected] = Math.max(currentMax, Math.round(rootFreq * freqScale));
  };

  for (const root of Object.keys(core)) {
    const len = root.length;
    if (len < 3) continue;

    // Common abbreviations/special words to skip programmatical endings
    if (['etc', 'doc', 'ok', 'yes', 'no', 'ie', 'eg', 'vs'].includes(root)) continue;

    // Pluralization / Third-person singular verb (-s, -es)
    if (root.endsWith('y')) {
      // family -> families
      if (!['a','e','i','o','u'].includes(root[len - 2])) {
        add(root, root.slice(0, len - 1) + 'ies', 0.85);
        // past tense: family -> familied
        add(root, root.slice(0, len - 1) + 'ied', 0.6);
      } else {
        // play -> plays
        add(root, root + 's', 0.9);
      }
    } else if (root.endsWith('ch') || root.endsWith('sh') || root.endsWith('s') || root.endsWith('x') || root.endsWith('z')) {
      add(root, root + 'es', 0.85);
    } else if (root.endsWith('e')) {
      add(root, root + 's', 0.9);
    } else {
      add(root, root + 's', 0.9);
    }

    // Gerund (-ing) and Past Tense / Past Participle (-ed) for verbs
    if (root.endsWith('e')) {
      // create -> creating, created
      add(root, root.slice(0, len - 1) + 'ing', 0.8);
      add(root, root + 'd', 0.8);
    } else if (root.endsWith('y')) {
      // play -> playing, played
      if (['a','e','i','o','u'].includes(root[len - 2])) {
        add(root, root + 'ing', 0.8);
        add(root, root + 'ed', 0.8);
      }
    } else if (root.endsWith('t') || root.endsWith('p') || root.endsWith('g') || root.endsWith('n') || root.endsWith('d')) {
      // fit -> fitting, fitted (double consonant, simplified helper)
      const lastChar = root[len - 1];
      const prevChar = root[len - 2];
      const prevPrevChar = root[len - 3] || '';
      const isShortVowel = ['a','e','i','o','u'].includes(prevChar) && !['a','e','i','o','u'].includes(prevPrevChar);
      
      if (isShortVowel && len <= 4) {
        add(root, root + lastChar + 'ing', 0.85);
        add(root, root + lastChar + 'ed', 0.85);
      } else {
        add(root, root + 'ing', 0.8);
        add(root, root + 'ed', 0.8);
      }
    } else {
      add(root, root + 'ing', 0.8);
      add(root, root + 'ed', 0.8);
    }

    // Adverbs (-ly) for adjectives
    if (root.endsWith('y') && len > 3) {
      // happy -> happily
      add(root, root.slice(0, len - 1) + 'ily', 0.75);
    } else if (root.endsWith('le')) {
      // gentle -> gently
      add(root, root.slice(0, len - 1) + 'y', 0.75);
    } else if (!root.endsWith('ly')) {
      add(root, root + 'ly', 0.75);
    }

    // Comparative/Superlative (-er, -est)
    if (len <= 5 && !root.endsWith('ly')) {
      if (root.endsWith('e')) {
        add(root, root + 'r', 0.6);
        add(root, root + 'st', 0.6);
      } else if (root.endsWith('y')) {
        add(root, root.slice(0, len - 1) + 'ier', 0.6);
        add(root, root.slice(0, len - 1) + 'iest', 0.6);
      } else {
        add(root, root + 'er', 0.6);
        add(root, root + 'est', 0.6);
      }
    }
  }

  // Inject a small batch of common technical/programming words to ensure pristine coding dictionaries
  const technicalWords = [
    'json', 'typescript', 'javascript', 'api', 'apis', 'backend', 'frontend', 'server', 'servers',
    'database', 'databases', 'npm', 'vite', 'react', 'css', 'html', 'router', 'eslint', 'tsconfig',
    'git', 'github', 'repo', 'repos', 'developer', 'developers', 'compilation', 'linter', 'lint',
    'formatter', 'format', 'minify', 'bundle', 'bundler', 'esbuild', 'postcss', 'tailwindcss',
    'chrome', 'firefox', 'safari', 'browser', 'browsers', 'client', 'clients', 'web', 'websites',
    'applet', 'applets', 'sdk', 'sdks', 'firebase', 'firestore', 'auth', 'oauth', 'token', 'tokens'
  ];
  for (const word of technicalWords) {
    expanded[word] = 75;
  }

  return expanded;
}
