import { TextError } from '../types';
import { dictionaryManager } from './dictionary';

/**
 * An offline rule-based grammar, style, and spelling analyzer.
 */
export function analyzeText(text: string): TextError[] {
  const errors: TextError[] = [];
  if (!text) return errors;

  // 1. Double Spaces Rule
  let doubleSpaceMatch;
  const doubleSpaceRegex = / {2,}/g;
  while ((doubleSpaceMatch = doubleSpaceRegex.exec(text)) !== null) {
    errors.push({
      id: `grammar-space-${doubleSpaceMatch.index}`,
      word: doubleSpaceMatch[0],
      originalWord: doubleSpaceMatch[0],
      index: doubleSpaceMatch.index,
      length: doubleSpaceMatch[0].length,
      suggestions: [' '],
      type: 'punctuation',
      message: 'Double spacing detected',
      explanation: 'Use only a single space between words to maintain professional, standard formatting.'
    });
  }

  // 2. Punctuation Spacing Rule (e.g., "hello , world" -> "hello, world")
  let punctSpacingMatch;
  const punctSpacingRegex = /(\w+)\s+([.,!?;:])(?!\w)/g;
  while ((punctSpacingMatch = punctSpacingRegex.exec(text)) !== null) {
    const fullMatch = punctSpacingMatch[0];
    const word = punctSpacingMatch[1];
    const mark = punctSpacingMatch[2];
    errors.push({
      id: `punctuation-spacing-${punctSpacingMatch.index}`,
      word: fullMatch,
      originalWord: fullMatch,
      index: punctSpacingMatch.index,
      length: fullMatch.length,
      suggestions: [`${word}${mark}`],
      type: 'punctuation',
      message: 'Unnecessary space before punctuation',
      explanation: `Do not put spaces before punctuation marks like '${mark}'. Place them directly after the preceding word.`
    });
  }

  // Split text into sentences for sentence-level analysis
  // A regex that matches periods, question marks, or exclamations, followed by space or end of line.
  const sentenceRegex = /([^.!?]+[.!?]*\s*)/g;
  let sentenceMatch;
  let textIndex = 0;

  while ((sentenceMatch = sentenceRegex.exec(text)) !== null) {
    const sentenceFull = sentenceMatch[0];
    const sentenceIndex = sentenceMatch.index;
    const sentenceTrimmed = sentenceFull.trim();

    if (!sentenceTrimmed) continue;

    // A. Sentence Capitalisation check
    // Find the first letter in the sentence
    const firstLetterMatch = /^[^\w]*([a-z])/.exec(sentenceFull);
    if (firstLetterMatch) {
      const letter = firstLetterMatch[1];
      const letterIndex = sentenceIndex + sentenceFull.indexOf(letter);
      errors.push({
        id: `cap-sentence-${letterIndex}`,
        word: letter,
        originalWord: letter,
        index: letterIndex,
        length: 1,
        suggestions: [letter.toUpperCase()],
        type: 'capitalization',
        message: 'Sentence should start with a capital letter',
        explanation: 'Always capitalise the first word of a sentence to ensure correct grammatical structure.'
      });
    }

    // B. Check for missing ending punctuation on reasonably long sentences
    const isAtEnd = (sentenceIndex + sentenceFull.length) >= text.trim().length;
    if (isAtEnd && sentenceTrimmed.length > 10 && !/[.!?]$/.test(sentenceTrimmed)) {
      errors.push({
        id: `punctuation-missing-${sentenceIndex + sentenceFull.length}`,
        word: sentenceTrimmed.slice(-1),
        originalWord: sentenceTrimmed.slice(-1),
        index: sentenceIndex + sentenceTrimmed.length - 1,
        length: 1,
        suggestions: [`${sentenceTrimmed.slice(-1)}.`],
        type: 'punctuation',
        message: 'Missing punctuation at the end of the sentence',
        explanation: 'This sentence appears to end without terminal punctuation. Add a period, question mark, or exclamation mark.'
      });
    }

    // Tokenise the sentence into words with their relative start indices
    const wordRegex = /\b([a-zA-Z0-9']+)[\b\s]*/g;
    let wordMatch;
    const sentenceWords: { word: string; index: number; fullMatch: string }[] = [];

    while ((wordMatch = wordRegex.exec(sentenceFull)) !== null) {
      sentenceWords.push({
        word: wordMatch[1],
        index: sentenceIndex + wordMatch.index,
        fullMatch: wordMatch[0]
      });
    }

    // Check rules on word sequences
    for (let i = 0; i < sentenceWords.length; i++) {
      const current = sentenceWords[i];
      const next = sentenceWords[i + 1];

      // Rule 3: Repeated Words (e.g. "the the")
      if (next && current.word.toLowerCase() === next.word.toLowerCase()) {
        errors.push({
          id: `grammar-repeated-${current.index}`,
          word: `${current.word} ${next.word}`,
          originalWord: `${current.word} ${next.word}`,
          index: current.index,
          length: next.index + next.word.length - current.index,
          suggestions: [current.word],
          type: 'style',
          message: `Repeated word: "${current.word}"`,
          explanation: `The word "${current.word}" is repeated consecutively. Consider deleting one of them.`
        });
      }

      // Rule 4: Article checks (a vs an)
      if (next && ['a', 'an'].includes(current.word.toLowerCase())) {
        const article = current.word.toLowerCase();
        const nextWord = next.word.toLowerCase();
        
        // Vowel sounds check (simplified heuristic with silent H and consonantal U exceptions)
        const startsWithVowel = /^[aeiou]/i.test(nextWord);
        const isSilentH = /^(hour|honest|honor|heir)/i.test(nextWord);
        const isConsonantalU = /^(university|unique|unit|union|useful|universe|one)/i.test(nextWord);

        let shouldBeAn = startsWithVowel;
        if (isSilentH) shouldBeAn = true;
        if (isConsonantalU) shouldBeAn = false;

        if (article === 'a' && shouldBeAn) {
          errors.push({
            id: `grammar-article-${current.index}`,
            word: current.word,
            originalWord: current.word,
            index: current.index,
            length: current.word.length,
            suggestions: [current.word === 'A' ? 'An' : 'an'],
            type: 'grammar',
            message: `Use "an" instead of "a" before "${next.word}"`,
            explanation: `Use the article "an" before words starting with vowel sounds (e.g., "an apple", "an hour").`
          });
        } else if (article === 'an' && !shouldBeAn) {
          errors.push({
            id: `grammar-article-${current.index}`,
            word: current.word,
            originalWord: current.word,
            index: current.index,
            length: current.word.length,
            suggestions: [current.word === 'An' ? 'A' : 'a'],
            type: 'grammar',
            message: `Use "a" instead of "an" before "${next.word}"`,
            explanation: `Use the article "a" before words starting with consonant sounds (e.g., "a car", "a university").`
          });
        }
      }

      // Rule 5: Pronoun "i" should always be capitalised
      if (current.word === 'i') {
        errors.push({
          id: `grammar-i-${current.index}`,
          word: current.word,
          originalWord: current.word,
          index: current.index,
          length: current.word.length,
          suggestions: ['I'],
          type: 'capitalization',
          message: 'The pronoun "I" should be capitalised',
          explanation: 'In English, the nominative singular personal pronoun "I" is always capitalised.'
        });
      }

      // Rule 6: Common proper noun capitalization
      const properNouns: { [lower: string]: string } = {
        english: 'English',
        spanish: 'Spanish',
        french: 'French',
        german: 'German',
        react: 'React',
        typescript: 'TypeScript',
        javascript: 'JavaScript',
        html: 'HTML',
        css: 'CSS',
        json: 'JSON',
        google: 'Google',
        vishwa: 'Vishwa',
        grammarly: 'Grammarly'
      };
      const lowerWord = current.word.toLowerCase();
      if (properNouns[lowerWord] && current.word !== properNouns[lowerWord]) {
        errors.push({
          id: `cap-proper-${current.index}`,
          word: current.word,
          originalWord: current.word,
          index: current.index,
          length: current.word.length,
          suggestions: [properNouns[lowerWord]],
          type: 'capitalization',
          message: `Capitalise proper noun: "${properNouns[lowerWord]}"`,
          explanation: `"${properNouns[lowerWord]}" is a proper noun/trademark and must be capitalised correctly.`
        });
      }

      // Rule 7: Subject-Verb agreement heuristics (simple pronoun + verb matches)
      if (next) {
        const verb = next.word.toLowerCase();
        const pronoun = current.word.toLowerCase();

        const singPronouns = ['he', 'she', 'it'];
        const plurPronouns = ['they', 'we', 'you', 'i'];

        // 'have' vs 'has'
        if (singPronouns.includes(pronoun) && verb === 'have') {
          errors.push({
            id: `agreement-have-${next.index}`,
            word: next.word,
            originalWord: next.word,
            index: next.index,
            length: next.word.length,
            suggestions: ['has'],
            type: 'grammar',
            message: `Subject-Verb agreement: use "has" after "${current.word}"`,
            explanation: `Third-person singular pronouns (he, she, it) take the verb form "has", not "have".`
          });
        } else if (plurPronouns.includes(pronoun) && verb === 'has' && pronoun !== 'i') {
          errors.push({
            id: `agreement-has-${next.index}`,
            word: next.word,
            originalWord: next.word,
            index: next.index,
            length: next.word.length,
            suggestions: ['have'],
            type: 'grammar',
            message: `Subject-Verb agreement: use "have" after "${current.word}"`,
            explanation: `Plural pronouns (we, they, you) and "I" take the verb form "have", not "has".`
          });
        }

        // 'was' vs 'were'
        if (['he', 'she', 'it', 'i'].includes(pronoun) && verb === 'were') {
          errors.push({
            id: `agreement-were-${next.index}`,
            word: next.word,
            originalWord: next.word,
            index: next.index,
            length: next.word.length,
            suggestions: ['was'],
            type: 'grammar',
            message: `Subject-Verb agreement: use "was" after "${current.word}"`,
            explanation: `Singular subjects take the verb "was", not "were" in the indicative past tense.`
          });
        } else if (['they', 'we', 'you'].includes(pronoun) && verb === 'was') {
          errors.push({
            id: `agreement-was-${next.index}`,
            word: next.word,
            originalWord: next.word,
            index: next.index,
            length: next.word.length,
            suggestions: ['were'],
            type: 'grammar',
            message: `Subject-Verb agreement: use "were" after "${current.word}"`,
            explanation: `Plural subjects take the verb "were", not "was" in the past tense.`
          });
        }

        // 'do' vs 'does'
        if (singPronouns.includes(pronoun) && verb === 'do') {
          errors.push({
            id: `agreement-do-${next.index}`,
            word: next.word,
            originalWord: next.word,
            index: next.index,
            length: next.word.length,
            suggestions: ['does'],
            type: 'grammar',
            message: `Subject-Verb agreement: use "does" after "${current.word}"`,
            explanation: `Singular third-person pronouns require the singular verb form "does".`
          });
        } else if (['they', 'we', 'you'].includes(pronoun) && verb === 'does') {
          errors.push({
            id: `agreement-does-${next.index}`,
            word: next.word,
            originalWord: next.word,
            index: next.index,
            length: next.word.length,
            suggestions: ['do'],
            type: 'grammar',
            message: `Subject-Verb agreement: use "do" after "${current.word}"`,
            explanation: `Plural pronouns require the plural verb form "do".`
          });
        }
      }

      // Rule 8: Passive Voice Style suggestion
      // "was completed by", "is handled by", "are designed by" etc.
      // Match auxiliary be + past participle + by
      if (next) {
        const aux = current.word.toLowerCase();
        const isBeAux = ['is', 'was', 'were', 'are', 'be', 'been', 'am'].includes(aux);
        if (isBeAux && sentenceWords[i + 2] && sentenceWords[i + 2].word.toLowerCase() === 'by') {
          const mainVerb = next.word;
          if (mainVerb.toLowerCase().endsWith('ed')) { // simple heuristic for regular past participle
            errors.push({
              id: `style-passive-${current.index}`,
              word: `${current.word} ${mainVerb} by`,
              originalWord: `${current.word} ${mainVerb} by`,
              index: current.index,
              length: sentenceWords[i + 2].index + sentenceWords[i + 2].word.length - current.index,
              suggestions: [], // Style checks don't always need exact drop-in replacements, but they warn
              type: 'style',
              message: 'Passive voice structure detected',
              explanation: 'Passive voice can make sentences wordy and less direct. Consider rewriting using an active voice.'
            });
          }
        }
      }

      // Rule 8B: Dynamic Tense and Auxiliary Shift Assistant (handling will, was, would, am, is, are, were)
      const currentLower = current.word.toLowerCase();
      const prev = i > 0 ? sentenceWords[i - 1] : null;
      const subj = prev ? prev.word.toLowerCase() : '';

      // Helper to guess present tense form of BE based on subject
      const getPresentBe = (subject: string): string => {
        if (!subject || subject === 'i') return 'am';
        if (['he', 'she', 'it'].includes(subject)) return 'is';
        if (['they', 'we', 'you'].includes(subject)) return 'are';
        return 'am'; // fallback
      };

      // Helper to guess present simple form of a verb based on subject (e.g. "go" vs "goes")
      const getPresentSimple = (verb: string, subject: string): string => {
        if (['he', 'she', 'it'].includes(subject)) {
          if (verb.endsWith('o') || verb.endsWith('sh') || verb.endsWith('ch') || verb.endsWith('x') || verb.endsWith('z')) {
            return `${verb}es`;
          }
          if (verb.endsWith('y') && !['a','e','i','o','u'].includes(verb[verb.length - 2])) {
            return `${verb.slice(0, -1)}ies`;
          }
          return `${verb}s`;
        }
        return verb;
      };

      // Helper to get base verb from ending-ing verb (simple heuristic)
      const getBaseFromIng = (ingVerb: string): string => {
        const lower = ingVerb.toLowerCase();
        if (lower.endsWith('ying')) {
          return `${ingVerb.slice(0, -4)}y`;
        }
        if (lower.endsWith('tting') || lower.endsWith('nning') || lower.endsWith('pping') || lower.endsWith('bbing') || lower.endsWith('mming') || lower.endsWith('dding') || lower.endsWith('gging') || lower.endsWith('rring')) {
          return ingVerb.slice(0, -4);
        }
        if (lower.endsWith('ing')) {
          // simple check for silent e, e.g. writing -> write, coming -> come
          const silentEWords: { [key: string]: string } = {
            'writing': 'write', 'coming': 'come', 'taking': 'take', 'making': 'make',
            'giving': 'give', 'having': 'have', 'loving': 'love', 'hoping': 'hope',
            'shaking': 'shake', 'living': 'live', 'driving': 'drive', 'using': 'use',
            'chasing': 'chase', 'dating': 'date', 'saving': 'save', 'naming': 'name',
            'sharing': 'share', 'gliding': 'glide', 'hating': 'hate', 'creating': 'create'
          };
          if (silentEWords[lower]) return silentEWords[lower];
          return ingVerb.slice(0, -3);
        }
        return ingVerb;
      };

      // 1. WAS/WERE + VERB-ING (Past Continuous -> Present Continuous or Future)
      if (next && ['was', 'were'].includes(currentLower) && next.word.toLowerCase().endsWith('ing')) {
        const beForm = getPresentBe(subj);
        const suggestion1 = `${beForm} ${next.word}`;
        const baseVerb = getBaseFromIng(next.word);
        const suggestion2 = `will ${baseVerb}`;
        const suggestion3 = getPresentSimple(baseVerb, subj);

        const matchCase = (s: string) => current.word[0] === current.word[0].toUpperCase() ? s[0].toUpperCase() + s.slice(1) : s;

        errors.push({
          id: `tense-shift-past-cont-${current.index}`,
          word: `${current.word} ${next.word}`,
          originalWord: `${current.word} ${next.word}`,
          index: current.index,
          length: next.index + next.word.length - current.index,
          suggestions: [matchCase(suggestion1), matchCase(suggestion2), matchCase(suggestion3)],
          type: 'style',
          message: `Consider present/future: "${suggestion1}" or "${suggestion3}"`,
          explanation: `Changing "${current.word} ${next.word}" shifts the action to the present or active future, making your expression more direct and immediate.`
        });
      }

      // 2. WOULD BE + VERB-ING (Conditional Continuous -> Present/Future Active)
      else if (next && sentenceWords[i + 2] && currentLower === 'would' && next.word.toLowerCase() === 'be' && sentenceWords[i + 2].word.toLowerCase().endsWith('ing')) {
        const verbIng = sentenceWords[i + 2];
        const beForm = getPresentBe(subj);
        const baseVerb = getBaseFromIng(verbIng.word);
        const suggestion1 = `${beForm} ${verbIng.word}`;
        const suggestion2 = `will be ${verbIng.word}`;
        const suggestion3 = `will ${baseVerb}`;

        const matchCase = (s: string) => current.word[0] === current.word[0].toUpperCase() ? s[0].toUpperCase() + s.slice(1) : s;

        errors.push({
          id: `tense-shift-would-be-cont-${current.index}`,
          word: `${current.word} ${next.word} ${verbIng.word}`,
          originalWord: `${current.word} ${next.word} ${verbIng.word}`,
          index: current.index,
          length: verbIng.index + verbIng.word.length - current.index,
          suggestions: [matchCase(suggestion1), matchCase(suggestion2), matchCase(suggestion3)],
          type: 'style',
          message: `Consider active present/future: "${suggestion1}"`,
          explanation: `The conditional continuous phrase "${current.word} be ${verbIng.word}" can be made more definite and direct by using the present continuous or simple future tense.`
        });
      }

      // 3. WILL BE + VERB-ING (Future Continuous -> Present Continuous or Simple Future)
      else if (next && sentenceWords[i + 2] && currentLower === 'will' && next.word.toLowerCase() === 'be' && sentenceWords[i + 2].word.toLowerCase().endsWith('ing')) {
        const verbIng = sentenceWords[i + 2];
        const beForm = getPresentBe(subj);
        const baseVerb = getBaseFromIng(verbIng.word);
        const suggestion1 = `will ${baseVerb}`;
        const suggestion2 = `${beForm} ${verbIng.word}`;
        const suggestion3 = getPresentSimple(baseVerb, subj);

        const matchCase = (s: string) => current.word[0] === current.word[0].toUpperCase() ? s[0].toUpperCase() + s.slice(1) : s;

        errors.push({
          id: `tense-shift-will-be-cont-${current.index}`,
          word: `${current.word} ${next.word} ${verbIng.word}`,
          originalWord: `${current.word} ${next.word} ${verbIng.word}`,
          index: current.index,
          length: verbIng.index + verbIng.word.length - current.index,
          suggestions: [matchCase(suggestion1), matchCase(suggestion2), matchCase(suggestion3)],
          type: 'style',
          message: `Simplify future form: "${suggestion1}"`,
          explanation: `Replacing the future continuous "${current.word} be ${verbIng.word}" with the simple future or present continuous makes the sentence cleaner and easier to read.`
        });
      }

      // 4. WOULD + BASE VERB (Conditional -> Simple Future or Present Simple)
      else if (next && currentLower === 'would' && next.word.toLowerCase() !== 'be') {
        const commonBaseVerbs = [
          'go', 'do', 'like', 'want', 'think', 'have', 'need', 'make', 'take', 'come', 'see', 
          'write', 'say', 'get', 'know', 'look', 'use', 'find', 'give', 'tell', 'work', 'call', 
          'try', 'ask', 'feel', 'become', 'leave', 'put', 'mean', 'keep', 'let', 'begin', 
          'seem', 'help', 'show', 'hear', 'play', 'run', 'move', 'live', 'believe', 'bring', 
          'hold', 'provide', 'start', 'love', 'hope', 'wish', 'enjoy'
        ];
        const verb = next.word.toLowerCase();
        if (commonBaseVerbs.includes(verb) || (verb.length > 2 && !verb.endsWith('ed') && !verb.endsWith('ing') && !verb.endsWith('s'))) {
          const suggestion1 = `will ${next.word}`;
          const suggestion2 = getPresentSimple(next.word, subj);

          const matchCase = (s: string) => current.word[0] === current.word[0].toUpperCase() ? s[0].toUpperCase() + s.slice(1) : s;

          errors.push({
            id: `tense-shift-would-base-${current.index}`,
            word: `${current.word} ${next.word}`,
            originalWord: `${current.word} ${next.word}`,
            index: current.index,
            length: next.index + next.word.length - current.index,
            suggestions: [matchCase(suggestion1), matchCase(suggestion2)],
            type: 'style',
            message: `Consider direct action: "${suggestion1}" or "${suggestion2}"`,
            explanation: `Using "${suggestion1}" (definite future) or "${suggestion2}" (present tense) instead of the conditional "${current.word} ${next.word}" sounds more confident and direct.`
          });
        }
      }

      // 5. AM/IS/ARE + VERB-ING (Present Continuous -> Simple Present or Simple Future for variety)
      else if (next && ['am', 'is', 'are'].includes(currentLower) && next.word.toLowerCase().endsWith('ing')) {
        const baseVerb = getBaseFromIng(next.word);
        const suggestion1 = getPresentSimple(baseVerb, subj);
        const suggestion2 = `will ${baseVerb}`;

        const matchCase = (s: string) => current.word[0] === current.word[0].toUpperCase() ? s[0].toUpperCase() + s.slice(1) : s;

        errors.push({
          id: `tense-shift-pres-cont-${current.index}`,
          word: `${current.word} ${next.word}`,
          originalWord: `${current.word} ${next.word}`,
          index: current.index,
          length: next.index + next.word.length - current.index,
          suggestions: [matchCase(suggestion1), matchCase(suggestion2)],
          type: 'style',
          message: `Consider simpler phrasing: "${suggestion1}"`,
          explanation: `The present continuous form "${current.word} ${next.word}" can sometimes be simplified to the present simple "${suggestion1}" or future "${suggestion2}" for active sentence flow.`
        });
      }

      // Rule 9: Redundancies / Clichés
      const redundantPhrases: { [phrase: string]: string } = {
        'very unique': 'unique',
        'absolutely essential': 'essential',
        'completely filled': 'filled',
        'past history': 'history',
        'future plans': 'plans',
        'unexpected surprise': 'surprise',
        'blend together': 'blend'
      };

      if (next) {
        const twoWordPhrase = `${current.word.toLowerCase()} ${next.word.toLowerCase()}`;
        if (redundantPhrases[twoWordPhrase]) {
          errors.push({
            id: `style-redundant-${current.index}`,
            word: `${current.word} ${next.word}`,
            originalWord: `${current.word} ${next.word}`,
            index: current.index,
            length: next.index + next.word.length - current.index,
            suggestions: [redundantPhrases[twoWordPhrase]],
            type: 'style',
            message: `Wordy phrase: "${current.word} ${next.word}"`,
            explanation: `The phrase is redundant. "${redundantPhrases[twoWordPhrase]}" conveys the same meaning more concisely.`
          });
        }
      }

      // Rule 10: Standard Spelling checks (Only if not flagged by any capitalization/grammar rules above)
      const isAlreadyFlagged = errors.some(
        (e) => e.index <= current.index && (e.index + e.length) >= (current.index + current.word.length)
      );

      if (!isAlreadyFlagged) {
        const isSpelledRight = dictionaryManager.isValidWord(current.word);
        if (!isSpelledRight) {
          // Calculate top 5 spelling suggestions
          const sList = dictionaryManager.getSuggestions(current.word, 5);
          errors.push({
            id: `spelling-${current.index}`,
            word: current.word,
            originalWord: current.word,
            index: current.index,
            length: current.word.length,
            suggestions: sList,
            type: 'spelling',
            message: `Possible spelling error: "${current.word}"`,
          });
        }
      }
    }
  }

  // Sort errors by index
  return errors.sort((a, b) => a.index - b.index);
}

/**
 * Calculates document stats for overall dashboard feedback.
 */
export function calculateStats(text: string, errors: TextError[]): any {
  if (!text) {
    return {
      words: 0,
      chars: 0,
      sentences: 0,
      readingTime: 0,
      spellingErrors: 0,
      grammarErrors: 0,
      score: 100
    };
  }

  const chars = text.length;
  const wordsArray = text.trim().split(/\s+/).filter(Boolean);
  const words = wordsArray.length;

  const sentencesArray = text.split(/[.!?]+/).filter((s) => s.trim().length > 0);
  const sentences = sentencesArray.length;

  const readingTime = Math.max(1, Math.round(words / 200)); // ~200 WPM

  const spellingCount = errors.filter((e) => e.type === 'spelling').length;
  const grammarCount = errors.filter((e) => e.type !== 'spelling').length;

  // Deduct score based on errors per 100 words
  const errorDensity = words > 0 ? (errors.length / words) * 100 : 0;
  const score = Math.max(10, Math.min(100, Math.round(100 - (errorDensity * 4.5))));

  return {
    words,
    chars,
    sentences,
    readingTime,
    spellingErrors: spellingCount,
    grammarErrors: grammarCount,
    score
  };
}
