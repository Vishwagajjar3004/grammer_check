import { BKTreeNode } from '../types';
import { getLevenshteinDistance } from './levenshtein';

export class BKTree {
  root: BKTreeNode | null = null;

  constructor(words?: string[]) {
    if (words) {
      this.build(words);
    }
  }

  /**
   * Resets and builds the BK-Tree from an array of words
   */
  build(words: string[]): void {
    this.root = null;
    for (let i = 0; i < words.length; i++) {
      this.insert(words[i]);
    }
  }

  /**
   * Inserts a single word into the BK-Tree
   */
  insert(word: string): void {
    const cleanWord = word.toLowerCase().trim();
    if (!cleanWord) return;

    if (!this.root) {
      this.root = { word: cleanWord, children: {} };
      return;
    }

    let curr = this.root;
    while (true) {
      const d = getLevenshteinDistance(cleanWord, curr.word);
      if (d === 0) {
        return; // Word already exists in tree
      }

      if (curr.children[d]) {
        curr = curr.children[d];
      } else {
        curr.children[d] = { word: cleanWord, children: {} };
        break;
      }
    }
  }

  /**
   * Searches the BK-Tree for words with Levenshtein distance <= tolerance.
   * Returns a list of candidate words along with their distances.
   */
  search(target: string, tolerance: number): Array<{ word: string; distance: number }> {
    const results: Array<{ word: string; distance: number }> = [];
    if (!this.root) return results;

    const cleanTarget = target.toLowerCase().trim();
    if (!cleanTarget) return results;

    const queue: BKTreeNode[] = [this.root];

    while (queue.length > 0) {
      const node = queue.shift()!;
      const d = getLevenshteinDistance(cleanTarget, node.word);

      if (d <= tolerance) {
        results.push({ word: node.word, distance: d });
      }

      // Check children in the range [d - tolerance, d + tolerance]
      const minDistance = d - tolerance;
      const maxDistance = d + tolerance;

      for (const distKey of Object.keys(node.children)) {
        const dist = parseInt(distKey, 10);
        if (dist >= minDistance && dist <= maxDistance) {
          queue.push(node.children[dist]);
        }
      }
    }

    return results;
  }
}
