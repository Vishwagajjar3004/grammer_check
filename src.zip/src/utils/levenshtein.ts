/**
 * Calculates the Levenshtein Distance between two strings.
 * This is the minimum number of single-character edits (insertions, deletions or substitutions)
 * required to change one word into the other.
 */
export function getLevenshteinDistance(a: string, b: string): number {
  const m = a.length;
  const n = b.length;

  // Optimize base cases
  if (m === 0) return n;
  if (n === 0) return m;

  // We can use a 2D matrix or just two rows for space optimization
  let prevRow = Array.from({ length: n + 1 }, (_, i) => i);
  let currRow = new Array<number>(n + 1);

  for (let i = 1; i <= m; i++) {
    currRow[0] = i;
    for (let j = 1; j <= n; j++) {
      const cost = a[i - 1] === b[j - 1] ? 0 : 1;
      currRow[j] = Math.min(
        currRow[j - 1] + 1,      // Insertion
        prevRow[j] + 1,          // Deletion
        prevRow[j - 1] + cost    // Substitution
      );
    }
    // Swap rows
    prevRow = [...currRow];
  }

  return prevRow[n];
}
