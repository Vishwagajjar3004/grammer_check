export interface SpellingError {
  id: string;
  word: string;
  originalWord: string;
  index: number;
  length: number;
  suggestions: string[];
  type: 'spelling';
  message: string;
}

export interface GrammarError {
  id: string;
  word: string;
  originalWord: string;
  index: number;
  length: number;
  suggestions: string[];
  type: 'grammar' | 'capitalization' | 'punctuation' | 'style';
  message: string;
  explanation: string;
}

export type TextError = SpellingError | GrammarError;

export interface BKTreeNode {
  word: string;
  children: { [distance: number]: BKTreeNode };
}

export interface DictionaryData {
  words: string[];
  frequencies: { [word: string]: number };
}

export interface DocumentStats {
  words: number;
  chars: number;
  sentences: number;
  readingTime: number; // in minutes
  spellingErrors: number;
  grammarErrors: number;
  score: number; // readability/quality score out of 100
}
