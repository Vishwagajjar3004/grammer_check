import React, { useState, useEffect, useRef } from 'react';
import { analyzeText, calculateStats } from './utils/grammarEngine';
import { dictionaryManager } from './utils/dictionary';
import { TextError, DocumentStats } from './types';
import { StatsPanel } from './components/StatsPanel';
import { CorrectionsList } from './components/CorrectionsList';
import { DictionaryManager } from './components/DictionaryManager';
import { HelpSection } from './components/HelpSection';
import { AiCopilot } from './components/AiCopilot';
import { 
  Sparkles, 
  BookMarked, 
  HelpCircle, 
  Activity, 
  Play, 
  RefreshCw, 
  Check, 
  ChevronRight, 
  FileText,
  FileEdit,
  Eye,
  Settings2,
  Bookmark,
  Wifi,
  WifiOff,
  Cpu
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

// A pristine, comprehensive draft with multiple errors designed to showcase the offline rules engine
const SAMPLE_TEXT = `hello world. this is a short demonstration of the offline grammar assistant. he have a apple in his pocket, but it do not look fresh. the the software was developed by vishwa using typescript . it is absolutely essential to check your spelling at the schol before submitting future plans .`;

export default function App() {
  const [text, setText] = useState<string>(() => {
    return localStorage.getItem('grammar_assistant_current_text') || SAMPLE_TEXT;
  });
  const [errors, setErrors] = useState<TextError[]>([]);
  const [stats, setStats] = useState<DocumentStats>({
    words: 0,
    chars: 0,
    sentences: 0,
    readingTime: 0,
    spellingErrors: 0,
    grammarErrors: 0,
    score: 100
  });

  const [activeErrorId, setActiveErrorId] = useState<string | null>(null);
  const [activeLeftTab, setActiveLeftTab] = useState<'stats' | 'dictionary' | 'help' | 'copilot'>('stats');
  const [editorMode, setEditorMode] = useState<'edit' | 'review'>('edit');
  const [showToast, setShowToast] = useState(false);
  const [toastMessage, setToastMessage] = useState('');

  // AI-powered states for Dynamic Website features
  const [checkerMode, setCheckerMode] = useState<'offline' | 'ai'>('offline');
  const [isAiChecking, setIsAiChecking] = useState(false);
  const [aiErrors, setAiErrors] = useState<TextError[]>([]);
  const [apiStatus, setApiStatus] = useState<{ status: string; aiEnabled: boolean } | null>(null);

  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // Check API availability and key setup on launch
  useEffect(() => {
    fetch("/api/health")
      .then((res) => res.json())
      .then((data) => setApiStatus(data))
      .catch((err) => {
        console.error("API connection failed", err);
        setApiStatus({ status: "offline", aiEnabled: false });
      });
  }, []);

  // Analyze text and recalculate stats on content change
  const runProofread = () => {
    if (checkerMode === 'offline') {
      const analysisErrors = analyzeText(text);
      setErrors(analysisErrors);
      setStats(calculateStats(text, analysisErrors));
    } else {
      // In AI mode, calculate simple document metadata (word count, chars, etc) but keep aiErrors
      const rawStats = calculateStats(text, aiErrors);
      setStats(rawStats);
    }
  };

  useEffect(() => {
    runProofread();
    localStorage.setItem('grammar_assistant_current_text', text);
  }, [text, checkerMode]);

  const handleTextChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setText(e.target.value);
  };

  // Run dynamic server-side Gemini deep proofread
  const handleAiDeepCheck = async () => {
    if (!text.trim()) {
      triggerToast("Document is empty. Enter some text first!");
      return;
    }
    setIsAiChecking(true);
    try {
      const response = await fetch("/api/proofread", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text })
      });
      const data = await response.json();
      if (response.ok) {
        setAiErrors(data.errors);
        setStats(calculateStats(text, data.errors));
        setCheckerMode('ai');
        setEditorMode('review');
        setActiveErrorId(data.errors.length > 0 ? data.errors[0].id : null);
        triggerToast(`AI Proofread found ${data.errors.length} issues!`);
      } else {
        triggerToast(data.error || "AI Proofread failed.");
      }
    } catch (err) {
      console.error(err);
      triggerToast("Failed to connect to AI server.");
    } finally {
      setIsAiChecking(false);
    }
  };

  // Loads the comprehensive sample draft
  const handleLoadSample = () => {
    setText(SAMPLE_TEXT);
    setCheckerMode('offline');
    setAiErrors([]);
    triggerToast('Sample text loaded successfully!');
  };

  const handleClearText = () => {
    setText('');
    setCheckerMode('offline');
    setAiErrors([]);
    triggerToast('Document cleared');
  };

  const triggerToast = (msg: string) => {
    setToastMessage(msg);
    setShowToast(true);
    setTimeout(() => setShowToast(false), 3000);
  };

  // Applies suggestions by replacing exact character index range
  const handleApplyCorrection = (err: TextError, suggestion: string) => {
    const before = text.slice(0, err.index);
    const after = text.slice(err.index + err.length);
    const updatedText = before + suggestion + after;
    
    // Shift subsequent indices if correcting in AI mode to avoid misalignments
    const lengthDiff = suggestion.length - err.length;
    let nextAiErrors = aiErrors;
    if (checkerMode === 'ai') {
      nextAiErrors = aiErrors
        .filter((e) => e.id !== err.id)
        .map((e) => {
          if (e.index > err.index) {
            return { ...e, index: e.index + lengthDiff };
          }
          return e;
        });
      setAiErrors(nextAiErrors);
    }

    setText(updatedText);
    triggerToast(`Applied: "${suggestion}"`);

    // If there is another error, select it or reset
    const activeErrorsList = checkerMode === 'ai' ? nextAiErrors : errors;
    const nextError = activeErrorsList.find((e) => e.id !== err.id);
    setActiveErrorId(nextError ? nextError.id : null);
  };

  // Ignores a word for the current session
  const handleIgnoreError = (err: TextError) => {
    if (checkerMode === 'ai') {
      const updated = aiErrors.filter((e) => e.id !== err.id);
      setAiErrors(updated);
      setStats(calculateStats(text, updated));
      setActiveErrorId(null);
      triggerToast(`Dismissed suggestion`);
    } else {
      dictionaryManager.ignoreWord(err.word);
      runProofread();
      setActiveErrorId(null);
      triggerToast(`Ignored: "${err.word}"`);
    }
  };

  // Adds misspelled word to user dictionary
  const handleAddToDictionary = (word: string) => {
    dictionaryManager.addUserWord(word);
    if (checkerMode === 'offline') {
      runProofread();
    }
    setActiveErrorId(null);
    triggerToast(`"${word}" added to User Dictionary`);
  };

  const handleSelectErrorCard = (id: string | null) => {
    setActiveErrorId(id);
    if (id) {
      // Auto switch to review mode to highlight visually if requested
      setEditorMode('review');
    }
  };

  // Render text segment tokens with highlight wrappers under Review Mode
  const renderHighlightedReviewText = () => {
    if (!text) {
      return (
        <div className="text-slate-400 italic text-center py-20 text-sm">
          Your document is empty. Type or load a sample above to begin.
        </div>
      );
    }

    const currentErrorsList = checkerMode === 'ai' ? aiErrors : errors;

    // Sort errors descending by index to avoid corrupting offsets
    const sortedErrors = [...currentErrorsList].sort((a, b) => b.index - a.index);
    let elements: React.ReactNode[] = [];
    let lastIndex = text.length;

    if (sortedErrors.length === 0) {
      return <div className="text-slate-700 whitespace-pre-wrap leading-relaxed text-sm">{text}</div>;
    }

    // Segment text backwards
    for (const err of sortedErrors) {
      // Text after the error
      if (err.index + err.length < lastIndex) {
        elements.unshift(
          <span key={`text-${err.index + err.length}`}>
            {text.slice(err.index + err.length, lastIndex)}
          </span>
        );
      }

      // Highlight style
      let underlineClass = 'wavy-underline-grammar';
      if (err.type === 'spelling') underlineClass = 'wavy-underline-spelling';
      if (err.type === 'capitalization') underlineClass = 'wavy-underline-capitalization';
      if (err.type === 'style') underlineClass = 'wavy-underline-style';

      const isSelected = activeErrorId === err.id;

      elements.unshift(
        <button
          key={`err-${err.id}`}
          onClick={() => setActiveErrorId(isSelected ? null : err.id)}
          className={`relative px-0.5 rounded cursor-pointer transition ${underlineClass} ${
            isSelected ? 'bg-indigo-50 text-indigo-900 font-medium ring-2 ring-indigo-200' : 'hover:bg-slate-50'
          }`}
          title={err.message}
        >
          {text.slice(err.index, err.index + err.length)}
        </button>
      );

      lastIndex = err.index;
    }

    // Remaining text at the beginning
    if (lastIndex > 0) {
      elements.unshift(<span key="text-start">{text.slice(0, lastIndex)}</span>);
    }

    return (
      <div className="whitespace-pre-wrap leading-loose text-slate-700 text-sm font-sans tracking-wide">
        {elements}
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-slate-50 font-sans selection:bg-blue-100 selection:text-blue-900 flex flex-col">
      
      {/* Toast Notification */}
      <AnimatePresence>
        {showToast && (
          <motion.div
            initial={{ opacity: 0, y: -20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -20, scale: 0.95 }}
            className="fixed top-5 left-1/2 -translate-x-1/2 z-50 bg-slate-900 text-white px-4 py-2 flex items-center gap-2 text-xs font-semibold border border-slate-800 rounded-lg shadow-md"
          >
            <Check className="w-3.5 h-3.5 text-emerald-400 stroke-[3]" />
            {toastMessage}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Top Header - High Density Design */}
      <header className="h-16 bg-white border-b border-slate-200 flex items-center justify-between px-6 shrink-0 sticky top-0 z-40 shadow-xs">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-blue-600 rounded flex items-center justify-center text-white font-bold text-xl font-display">
            G
          </div>
          <div>
            <h1 className="text-sm font-bold leading-none uppercase tracking-tight flex items-center gap-1.5 text-slate-850">
              Grammar Assistant
              <span className="text-[9px] bg-blue-50 border border-blue-100 px-1.5 py-0.5 rounded font-mono text-blue-700 font-bold uppercase">
                v1.0.4-alpha // INTERNAL_BUILD
              </span>
            </h1>
            <p className="text-[10px] text-slate-400 font-mono mt-0.5">LOCAL_OFFLINE_PROOFREADING_ENGINE</p>
          </div>
        </div>

        {/* Lead Architect & Score Completion Progress */}
        <div className="flex gap-6 items-center">
          <div className="hidden sm:block text-right">
            <p className="text-[9px] text-slate-400 uppercase font-semibold font-mono tracking-wider">Lead Architect</p>
            <p className="text-xs font-semibold text-slate-700">Vishwa</p>
          </div>
          <div className="hidden sm:block h-8 w-[1px] bg-slate-200"></div>
          
          <div className="flex flex-col items-end">
            <div className="flex items-center gap-2">
              <span className={`w-2 h-2 rounded-full ${stats.score >= 90 ? 'bg-emerald-500' : stats.score >= 75 ? 'bg-amber-500' : 'bg-rose-500'}`}></span>
              <span className="text-[10px] font-bold font-mono text-slate-700 uppercase">{stats.score}% HEALTH</span>
            </div>
            <div className="w-28 h-1.5 bg-slate-100 rounded-full mt-1 overflow-hidden border border-slate-200/50">
              <div 
                className={`h-full transition-all duration-500 ${stats.score >= 90 ? 'bg-emerald-500' : stats.score >= 75 ? 'bg-amber-500' : 'bg-rose-500'}`}
                style={{ width: `${stats.score}%` }}
              ></div>
            </div>
          </div>

          <div className="h-8 w-[1px] bg-slate-200"></div>

          {/* Action toolbar */}
          <div className="flex items-center gap-1.5">
            {/* API Status Badge */}
            {apiStatus && (
              <div className="hidden md:flex items-center gap-1 px-2 py-1 bg-slate-100 rounded text-[10px] font-bold border border-slate-200">
                {apiStatus.aiEnabled ? (
                  <>
                    <Wifi className="w-3 h-3 text-emerald-500" />
                    <span className="text-slate-600">AI READY</span>
                  </>
                ) : (
                  <>
                    <WifiOff className="w-3 h-3 text-amber-500" />
                    <span className="text-slate-500">LOCAL ONLY</span>
                  </>
                )}
              </div>
            )}

            <button
              onClick={handleAiDeepCheck}
              disabled={isAiChecking}
              className="px-3 py-1.5 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white rounded text-[11px] font-bold transition flex items-center gap-1.5 cursor-pointer shadow-xs disabled:opacity-75"
              title="Check document with server-side Gemini 3.5 Flash for advanced context and styling"
            >
              <Sparkles className="w-3.5 h-3.5" />
              {isAiChecking ? "Proofreading..." : "AI Deep Check"}
            </button>

            <button
              onClick={handleLoadSample}
              className="px-2.5 py-1.5 bg-slate-50 hover:bg-slate-100 active:scale-95 text-slate-600 hover:text-slate-800 rounded text-[11px] font-bold border border-slate-200 transition flex items-center gap-1 cursor-pointer"
              title="Reset the editor with our comprehensive multi-error offline sample"
            >
              <Play className="w-3 h-3 fill-current" /> Load Sample
            </button>
            
            <button
              onClick={handleClearText}
              className="px-2 py-1.5 bg-white hover:bg-slate-50 text-slate-500 hover:text-slate-700 rounded text-[11px] font-semibold border border-slate-200 transition cursor-pointer"
            >
              Clear
            </button>
          </div>
        </div>
      </header>

      {/* Main Work Space */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 grid grid-cols-1 lg:grid-cols-12 gap-4">
        
        {/* Left Hand: Options and Stats panel (lg:span-3) */}
        <section className="lg:col-span-3 flex flex-col gap-4">
          
          {/* Navigation Tab rail */}
          <div className="bg-white rounded-lg border border-slate-200 p-1 flex shadow-xs shrink-0 flex-wrap sm:flex-nowrap gap-0.5">
            <button
              onClick={() => setActiveLeftTab('stats')}
              className={`flex-1 py-1.5 px-2 rounded text-[10px] font-bold uppercase tracking-wider transition flex items-center justify-center gap-1 cursor-pointer ${
                activeLeftTab === 'stats'
                  ? 'bg-slate-900 text-white shadow-sm'
                  : 'text-slate-500 hover:text-slate-850 hover:bg-slate-50'
              }`}
            >
              <Activity className="w-3 h-3" /> Stats
            </button>
            <button
              onClick={() => setActiveLeftTab('copilot')}
              className={`flex-1 py-1.5 px-2 rounded text-[10px] font-bold uppercase tracking-wider transition flex items-center justify-center gap-1 cursor-pointer ${
                activeLeftTab === 'copilot'
                  ? 'bg-slate-900 text-white shadow-sm'
                  : 'text-slate-500 hover:text-slate-850 hover:bg-slate-50'
              }`}
            >
              <Sparkles className="w-3 h-3 text-indigo-500" /> Co-Pilot
            </button>
            <button
              onClick={() => setActiveLeftTab('dictionary')}
              className={`flex-1 py-1.5 px-2 rounded text-[10px] font-bold uppercase tracking-wider transition flex items-center justify-center gap-1 cursor-pointer ${
                activeLeftTab === 'dictionary'
                  ? 'bg-slate-900 text-white shadow-sm'
                  : 'text-slate-500 hover:text-slate-850 hover:bg-slate-50'
              }`}
            >
              <BookMarked className="w-3 h-3" /> Lexicon
            </button>
            <button
              onClick={() => setActiveLeftTab('help')}
              className={`flex-1 py-1.5 px-2 rounded text-[10px] font-bold uppercase tracking-wider transition flex items-center justify-center gap-1 cursor-pointer ${
                activeLeftTab === 'help'
                  ? 'bg-slate-900 text-white shadow-sm'
                  : 'text-slate-500 hover:text-slate-850 hover:bg-slate-50'
              }`}
            >
              <HelpCircle className="w-3 h-3" /> Guide
            </button>
          </div>

          <div className="flex-1 flex flex-col">
            {activeLeftTab === 'stats' && <StatsPanel stats={stats} />}
            {activeLeftTab === 'dictionary' && <DictionaryManager onUpdateRequired={runProofread} />}
            {activeLeftTab === 'help' && <HelpSection />}
            {activeLeftTab === 'copilot' && (
              <AiCopilot 
                text={text} 
                onUpdateText={(newText) => {
                  setText(newText);
                  setAiErrors([]);
                  setCheckerMode('offline');
                }} 
                onTriggerToast={triggerToast} 
              />
            )}
          </div>
        </section>

        {/* Middle: Text Editor canvas (lg:span-6) */}
        <section className="lg:col-span-6 flex flex-col gap-2.5">
          
          {/* Editor Header / Modes */}
          <div className="flex items-center justify-between px-1">
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mr-2">Document Editor</span>
              
              {/* Active Engine Toggle */}
              <div className="flex bg-slate-200/50 rounded-full p-0.5 text-[9px] font-bold border border-slate-200">
                <button
                  onClick={() => setCheckerMode('offline')}
                  className={`px-2 py-0.5 rounded-full transition cursor-pointer ${
                    checkerMode === 'offline'
                      ? 'bg-slate-750 text-white'
                      : 'text-slate-500 hover:text-slate-800'
                  }`}
                >
                  Offline Rules
                </button>
                <button
                  onClick={() => {
                    if (aiErrors.length === 0) {
                      handleAiDeepCheck();
                    } else {
                      setCheckerMode('ai');
                    }
                  }}
                  className={`px-2 py-0.5 rounded-full transition cursor-pointer flex items-center gap-1 ${
                    checkerMode === 'ai'
                      ? 'bg-blue-600 text-white'
                      : 'text-slate-500 hover:text-slate-800'
                  }`}
                >
                  <Sparkles className="w-2.5 h-2.5" /> AI Engine
                </button>
              </div>
            </div>

            {/* Mode Switcher */}
            <div className="bg-slate-200/60 rounded p-0.5 flex text-[10px] font-bold border border-slate-200">
              <button
                onClick={() => setEditorMode('edit')}
                className={`px-3 py-1 rounded transition flex items-center gap-1 cursor-pointer ${
                  editorMode === 'edit'
                    ? 'bg-white text-slate-800 shadow-xs border border-slate-200/30'
                    : 'text-slate-500 hover:text-slate-800'
                }`}
              >
                <FileEdit className="w-2.5 h-2.5" /> Edit Mode
              </button>
              <button
                onClick={() => setEditorMode('review')}
                className={`px-3 py-1 rounded transition flex items-center gap-1 cursor-pointer ${
                  editorMode === 'review'
                    ? 'bg-white text-slate-800 shadow-xs border border-slate-200/30'
                    : 'text-slate-500 hover:text-slate-800'
                }`}
              >
                <Eye className="w-2.5 h-2.5" /> Review Canvas
              </button>
            </div>
          </div>

          {/* Interactive Core Canvas Container */}
          <div className="flex-1 bg-white rounded-lg border border-slate-200 shadow-sm flex flex-col overflow-hidden min-h-[480px]">
            {editorMode === 'edit' ? (
              <div className="flex-1 flex flex-col relative p-4">
                <textarea
                  ref={textareaRef}
                  value={text}
                  onChange={handleTextChange}
                  placeholder="Start typing your draft here or load the sample above to test..."
                  className="w-full flex-1 outline-none resize-none bg-transparent text-slate-800 leading-relaxed text-sm font-sans placeholder-slate-300 custom-scrollbar"
                />
                <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-[10px] text-slate-400 font-mono">
                  <span>{checkerMode === 'ai' ? 'AI_DRAFT_BUFFER' : 'OFFLINE_BUFFER_SAVED'}</span>
                  <span>{text.length} characters</span>
                </div>
              </div>
            ) : (
              <div className="flex-1 p-5 overflow-y-auto custom-scrollbar flex flex-col">
                <div className="flex-1">
                  {renderHighlightedReviewText()}
                </div>
                <div className="pt-3.5 border-t border-slate-100 flex items-center justify-between text-[10px] text-blue-600 font-bold bg-white/90 sticky bottom-0">
                  <span className="uppercase tracking-wider">CLICK HIGHLIGHTED WORDS FOR DETAILED CORRECTIONS</span>
                  <span className="text-slate-400 font-mono">INTERACTIVE_MODE // REVIEW</span>
                </div>
              </div>
            )}
          </div>
        </section>

        {/* Right Hand: Correction Details sidebar (lg:span-3) */}
        <section className="lg:col-span-3">
          <CorrectionsList
            errors={checkerMode === 'ai' ? aiErrors : errors}
            onApply={handleApplyCorrection}
            onIgnore={handleIgnoreError}
            onAddToDictionary={handleAddToDictionary}
            activeErrorId={activeErrorId}
            onSelectError={handleSelectErrorCard}
          />
        </section>

      </main>

      {/* Footer / System Log - High Density Style */}
      <footer className="h-8 bg-slate-100 border-t border-slate-200 px-6 flex items-center justify-between text-[9px] font-mono text-slate-500 shrink-0">
        <div className="flex gap-4">
          <span>LOG: Dict Loaded... OK</span>
          <span>LOG: Levenshtein Engine... OK</span>
          <span className="hidden md:inline">LOG: AI Proofreader Endpoint... {apiStatus?.aiEnabled ? 'ACTIVE' : 'OFFLINE'}</span>
        </div>
        <div className="flex items-center gap-2">
          <span className={`w-1.5 h-1.5 rounded-full ${apiStatus?.aiEnabled ? 'bg-emerald-500 animate-pulse' : 'bg-amber-400'}`}></span>
          <span className="font-bold tracking-wider uppercase">
            {checkerMode === 'ai' ? 'SYSTEM ACTIVE // AI_CO_PILOT_ENGINE' : 'SYSTEM STABLE // OFFLINE_RULES_ENGINE'}
          </span>
        </div>
      </footer>
    </div>
  );
}
