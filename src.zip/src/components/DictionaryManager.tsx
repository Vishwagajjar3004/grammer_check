import React, { useState } from 'react';
import { dictionaryManager } from '../utils/dictionary';
import { BookMarked, Plus, Trash2, Sliders, Sparkles, RefreshCw, Info, Check, BrainCircuit } from 'lucide-react';
import { motion } from 'motion/react';

interface DictionaryManagerProps {
  onUpdateRequired: () => void; // Trigger callback to recheck document when dictionary changes
}

export const DictionaryManager: React.FC<DictionaryManagerProps> = ({ onUpdateRequired }) => {
  const [userWords, setUserWords] = useState<string[]>(dictionaryManager.getUserWords());
  const [ignoredWords, setIgnoredWords] = useState<string[]>(dictionaryManager.getIgnoredWords());
  const [newWordInput, setNewWordInput] = useState('');
  
  // Sync States
  const [isSyncing, setIsSyncing] = useState(false);
  const [syncProgress, setSyncProgress] = useState(0);
  const [syncStatus, setSyncStatus] = useState<'idle' | 'checking' | 'building' | 'complete'>('idle');
  const [dictionarySize, setDictionarySize] = useState(dictionaryManager.getDictionarySize());

  const handleAddWord = (e: React.FormEvent) => {
    e.preventDefault();
    const clean = newWordInput.trim().toLowerCase();
    if (clean && !userWords.includes(clean)) {
      dictionaryManager.addUserWord(clean);
      setUserWords(dictionaryManager.getUserWords());
      setNewWordInput('');
      setDictionarySize(dictionaryManager.getDictionarySize());
      onUpdateRequired();
    }
  };

  const handleDeleteWord = (word: string) => {
    dictionaryManager.removeUserWord(word);
    setUserWords(dictionaryManager.getUserWords());
    setDictionarySize(dictionaryManager.getDictionarySize());
    onUpdateRequired();
  };

  const handleClearIgnored = () => {
    dictionaryManager.clearIgnoredWords();
    setIgnoredWords([]);
    onUpdateRequired();
  };

  const handleSyncDictionary = async () => {
    setIsSyncing(true);
    setSyncProgress(0);
    setSyncStatus('checking');

    // Phase 8: Offline upgrade sync simulation/calculation
    await new Promise((r) => setTimeout(r, 1000));
    setSyncStatus('building');
    
    const finalSize = await dictionaryManager.upgradeDictionary((progress) => {
      setSyncProgress(progress);
    });

    setSyncStatus('complete');
    setDictionarySize(finalSize);
    setIsSyncing(false);
    onUpdateRequired();
    
    setTimeout(() => {
      setSyncStatus('idle');
      setSyncProgress(0);
    }, 3000);
  };

  return (
    <div className="bg-white rounded-lg border border-slate-200 shadow-sm p-4 space-y-4 flex-1 flex flex-col">
      {/* Title */}
      <div className="flex items-center justify-between">
        <h3 className="text-[11px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2">
          <BookMarked className="w-4 h-4 text-blue-600" />
          Lexicon & Settings
        </h3>
        <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-slate-100 text-slate-600 border border-slate-200/50 font-bold">
          {dictionarySize.toLocaleString()} Words
        </span>
      </div>

      {/* Sync/Update Box */}
      <div className="bg-blue-50/50 rounded p-3.5 border border-blue-100 space-y-3">
        <div className="flex items-start gap-2">
          <div className="p-1.5 rounded bg-blue-100 border border-blue-200 text-blue-700 shrink-0 mt-0.5">
            <BrainCircuit className="w-3.5 h-3.5" />
          </div>
          <div>
            <h4 className="text-[10px] font-bold text-blue-900 flex items-center gap-1 uppercase tracking-wider">
              BK-Tree Dictionary Engine
              <Sparkles className="w-2.5 h-2.5 text-amber-500 fill-amber-500" />
            </h4>
            <p className="text-[10px] text-blue-800 leading-relaxed mt-0.5">
              Power spelling and suggestion lookups entirely offline with a custom Burkhard-Keller metric tree.
            </p>
          </div>
        </div>

        {/* Sync Status / Trigger button */}
        {syncStatus === 'idle' ? (
          <button
            onClick={handleSyncDictionary}
            className="w-full py-1.5 bg-blue-600 hover:bg-blue-700 active:scale-[0.99] transition text-white font-bold rounded text-[10px] flex items-center justify-center gap-1.5 cursor-pointer shadow-sm shadow-blue-100 uppercase tracking-wider"
          >
            <RefreshCw className="w-3 h-3" /> Check Dictionary Updates
          </button>
        ) : (
          <div className="space-y-1.5">
            <div className="flex items-center justify-between text-[10px]">
              <span className="text-blue-800 font-bold uppercase tracking-wider">
                {syncStatus === 'checking' && 'Querying local catalogs...'}
                {syncStatus === 'building' && 'Rebuilding BK-Tree metrics...'}
                {syncStatus === 'complete' && 'Rebuilt with 300,000+ words!'}
              </span>
              <span className="font-mono text-blue-900 font-bold">{syncProgress}%</span>
            </div>
            
            {/* Progress bar */}
            <div className="w-full h-1.5 bg-blue-100 rounded overflow-hidden">
              <div
                className="h-full bg-blue-600 transition-all duration-300"
                style={{ width: `${syncProgress}%` }}
              />
            </div>
            {syncStatus === 'complete' && (
              <div className="text-[9px] text-emerald-600 font-bold flex items-center gap-1 uppercase tracking-wider">
                <Check className="w-2.5 h-2.5 stroke-[3]" /> Offline lexicon upgraded and indexed.
              </div>
            )}
          </div>
        )}
      </div>

      {/* User Added Dictionary */}
      <div className="space-y-2.5">
        <h4 className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">User Dictionary</h4>
        
        {/* Form to add */}
        <form onSubmit={handleAddWord} className="flex gap-1.5">
          <input
            type="text"
            value={newWordInput}
            onChange={(e) => setNewWordInput(e.target.value)}
            placeholder="Add custom word (e.g., Vishwa)"
            className="flex-1 bg-slate-50 hover:bg-slate-100 focus:bg-white focus:ring-1 focus:ring-blue-400 focus:border-blue-400 outline-none border border-slate-200 rounded px-2.5 py-1 text-xs font-semibold transition placeholder-slate-400 text-slate-800"
          />
          <button
            type="submit"
            className="px-2.5 bg-blue-50 hover:bg-blue-100 text-blue-600 rounded text-xs font-bold transition border border-blue-200 flex items-center justify-center cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
          </button>
        </form>

        {/* Word chips */}
        <div className="max-h-[120px] overflow-y-auto custom-scrollbar border border-slate-200 rounded p-1.5 bg-slate-50/50 space-y-1">
          {userWords.length === 0 ? (
            <div className="text-center py-3 text-[10px] text-slate-400 italic">No custom words added yet.</div>
          ) : (
            <div className="flex flex-wrap gap-1">
              {userWords.map((word) => (
                <div
                  key={word}
                  className="px-1.5 py-0.5 bg-white border border-slate-200 rounded text-[10px] font-bold text-slate-700 flex items-center gap-1 shadow-xs"
                >
                  <span>{word}</span>
                  <button
                    onClick={() => handleDeleteWord(word)}
                    className="text-slate-400 hover:text-rose-500 rounded p-0.5 hover:bg-slate-50 cursor-pointer"
                    title="Remove word"
                  >
                    <Trash2 className="w-2.5 h-2.5" />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Ignored Words Manager */}
      <div className="space-y-2.5 pt-2.5 border-t border-slate-200">
        <div className="flex items-center justify-between">
          <h4 className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Session Ignored List</h4>
          {ignoredWords.length > 0 && (
            <button
              onClick={handleClearIgnored}
              className="text-[9px] text-rose-500 font-bold uppercase tracking-wider hover:underline cursor-pointer"
            >
              Clear All
            </button>
          )}
        </div>

        <div className="bg-slate-50/50 p-2.5 rounded border border-slate-150 text-[10px] text-slate-500 flex items-start gap-1.5 leading-relaxed">
          <Info className="w-3.5 h-3.5 text-slate-400 shrink-0 mt-0.5" />
          <div>
            Words you skip during checking are marked as ignored. Clear to restore checks.
          </div>
        </div>

        {ignoredWords.length > 0 && (
          <div className="flex flex-wrap gap-1 p-1 bg-white rounded border border-slate-150">
            {ignoredWords.map((w) => (
              <span key={w} className="px-1.5 py-0.5 rounded bg-slate-100 text-slate-600 font-mono text-[9px] font-semibold">
                {w}
              </span>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
