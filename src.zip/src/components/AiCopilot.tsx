import React, { useState } from 'react';
import { Sparkles, ArrowRight, RotateCcw, Check, X, Wand2, Type } from 'lucide-react';

interface AiCopilotProps {
  text: string;
  onUpdateText: (newText: string) => void;
  onTriggerToast: (msg: string) => void;
}

export function AiCopilot({ text, onUpdateText, onTriggerToast }: AiCopilotProps) {
  const [tone, setTone] = useState<'professional' | 'casual' | 'academic' | 'shorten' | 'expand'>('professional');
  const [customInstructions, setCustomInstructions] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [rewriteResult, setRewriteResult] = useState<{ rewrittenText: string; explanation: string } | null>(null);
  const [originalText, setOriginalText] = useState<string | null>(null);

  const tonesList = [
    { value: 'professional', label: 'Professional', desc: 'Authoritative, clear, and polite' },
    { value: 'casual', label: 'Casual', desc: 'Friendly, warm, and natural' },
    { value: 'academic', label: 'Academic', desc: 'Formal, precise, and objective' },
    { value: 'shorten', label: 'Concise', desc: 'Highly dense, cuts the fluff' },
    { value: 'expand', label: 'Descriptive', desc: 'Expressive and elaborate' },
  ] as const;

  const handleRewrite = async (selectedTone: typeof tone) => {
    if (!text.trim()) {
      onTriggerToast("Please enter some text in the editor first.");
      return;
    }
    setIsProcessing(true);
    try {
      const response = await fetch("/api/rewrite", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text, tone: selectedTone })
      });
      const data = await response.json();
      if (response.ok) {
        setOriginalText(text);
        setRewriteResult({
          rewrittenText: data.rewrittenText,
          explanation: data.explanation
        });
        onTriggerToast("AI Rewrite preview generated!");
      } else {
        onTriggerToast(data.error || "Failed to generate rewrite.");
      }
    } catch (err: any) {
      console.error(err);
      onTriggerToast("Network error during rewrite.");
    } finally {
      setIsProcessing(false);
    }
  };

  const handleCustomInstruct = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!text.trim()) {
      onTriggerToast("Please enter some text in the editor first.");
      return;
    }
    if (!customInstructions.trim()) return;

    setIsProcessing(true);
    try {
      const response = await fetch("/api/rewrite", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ 
          text, 
          tone: `custom instruction: "${customInstructions}"` 
        })
      });
      const data = await response.json();
      if (response.ok) {
        setOriginalText(text);
        setRewriteResult({
          rewrittenText: data.rewrittenText,
          explanation: data.explanation
        });
        onTriggerToast("AI Custom rewrite preview generated!");
      } else {
        onTriggerToast(data.error || "Failed to generate custom rewrite.");
      }
    } catch (err: any) {
      console.error(err);
      onTriggerToast("Network error during custom rewrite.");
    } finally {
      setIsProcessing(false);
    }
  };

  const handleAccept = () => {
    if (rewriteResult) {
      onUpdateText(rewriteResult.rewrittenText);
      setRewriteResult(null);
      setOriginalText(null);
      onTriggerToast("Applied AI rewrite to document!");
    }
  };

  const handleDiscard = () => {
    setRewriteResult(null);
    setOriginalText(null);
    onTriggerToast("Discarded AI rewrite");
  };

  return (
    <div className="bg-white rounded-lg border border-slate-200 shadow-sm p-4 space-y-4 flex-1 flex flex-col">
      <div className="flex items-center justify-between">
        <h3 className="text-[11px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-blue-600" />
          AI Co-Pilot & Styles
        </h3>
        <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-blue-50 text-blue-700 border border-blue-100 font-bold">
          LIVE_INTEGRATION
        </span>
      </div>

      {!rewriteResult ? (
        <div className="space-y-4 flex-1 flex flex-col justify-between">
          <div className="space-y-3.5">
            <p className="text-[10px] text-slate-500 leading-relaxed">
              Dynamically polish your drafts using advanced Gemini models. Choose a standard stylistic template below or write custom prompts.
            </p>

            {/* Standard Tones Grid */}
            <div className="space-y-2">
              <span className="text-[9px] font-bold text-slate-400 uppercase tracking-wider">Style Presets</span>
              <div className="grid grid-cols-1 gap-1.5 max-h-[190px] overflow-y-auto custom-scrollbar pr-0.5">
                {tonesList.map((t) => (
                  <button
                    key={t.value}
                    disabled={isProcessing}
                    onClick={() => {
                      setTone(t.value);
                      handleRewrite(t.value);
                    }}
                    className={`p-2.5 rounded border text-left transition flex items-center justify-between group cursor-pointer ${
                      tone === t.value
                        ? 'border-blue-500 bg-blue-50/40 text-blue-900'
                        : 'border-slate-150 hover:border-slate-300 bg-slate-50/30'
                    }`}
                  >
                    <div>
                      <div className="text-xs font-bold flex items-center gap-1">
                        {t.label}
                      </div>
                      <div className="text-[9px] text-slate-400 group-hover:text-slate-500 mt-0.5">
                        {t.desc}
                      </div>
                    </div>
                    <ArrowRight className="w-3.5 h-3.5 text-slate-400 group-hover:translate-x-0.5 transition" />
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Custom Instruction Prompt */}
          <div className="pt-3.5 border-t border-slate-200 space-y-2">
            <span className="text-[9px] font-bold text-slate-400 uppercase tracking-wider">Custom Edit Command</span>
            <form onSubmit={handleCustomInstruct} className="flex gap-1.5">
              <input
                type="text"
                value={customInstructions}
                onChange={(e) => setCustomInstructions(e.target.value)}
                placeholder="e.g., Translate to Spanish, make it punchy"
                disabled={isProcessing}
                className="flex-1 bg-slate-50 hover:bg-slate-100 focus:bg-white focus:ring-1 focus:ring-blue-400 focus:border-blue-400 outline-none border border-slate-200 rounded px-2.5 py-1.5 text-xs font-semibold transition placeholder-slate-400 text-slate-800"
              />
              <button
                type="submit"
                disabled={isProcessing || !customInstructions.trim()}
                className="px-3 bg-blue-600 hover:bg-blue-700 disabled:bg-slate-100 disabled:text-slate-400 text-white rounded text-xs font-bold transition flex items-center justify-center cursor-pointer"
              >
                <Wand2 className="w-3.5 h-3.5" />
              </button>
            </form>
          </div>
        </div>
      ) : (
        /* Rewrite Preview Screen */
        <div className="space-y-3.5 flex-1 flex flex-col justify-between">
          <div className="space-y-2.5 flex-1 overflow-y-auto max-h-[360px] custom-scrollbar pr-0.5">
            <div className="flex items-center justify-between">
              <span className="text-[9px] font-bold text-amber-500 uppercase tracking-wider flex items-center gap-1 font-mono">
                ✦ Previewing Changes
              </span>
              <span className="text-[8px] font-mono text-slate-400">TONE: {tone.toUpperCase()}</span>
            </div>

            {/* Explanation box */}
            <div className="p-2.5 bg-blue-50/50 border border-blue-100 rounded text-[10px] text-blue-800 leading-relaxed">
              <span className="font-bold uppercase tracking-wider text-[8px] block mb-0.5 text-blue-900">AI Stylist Explanation:</span>
              {rewriteResult.explanation}
            </div>

            {/* Diff/Text box */}
            <div className="p-3 bg-slate-50 border border-slate-200 rounded text-xs text-slate-700 leading-relaxed font-sans whitespace-pre-wrap">
              {rewriteResult.rewrittenText}
            </div>
          </div>

          <div className="pt-3 border-t border-slate-200 grid grid-cols-2 gap-2">
            <button
              onClick={handleDiscard}
              className="py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-[10px] font-bold rounded uppercase tracking-wider flex items-center justify-center gap-1 transition cursor-pointer"
            >
              <X className="w-3.5 h-3.5" /> Discard
            </button>
            <button
              onClick={handleAccept}
              className="py-2 bg-blue-600 hover:bg-blue-700 text-white text-[10px] font-bold rounded uppercase tracking-wider flex items-center justify-center gap-1 transition cursor-pointer"
            >
              <Check className="w-3.5 h-3.5" /> Apply
            </button>
          </div>
        </div>
      )}

      {isProcessing && (
        <div className="absolute inset-0 bg-white/70 backdrop-blur-xs flex flex-col items-center justify-center space-y-2.5 rounded-lg z-10">
          <div className="relative">
            <div className="w-8 h-8 rounded-full border-2 border-slate-100 border-t-blue-600 animate-spin" />
            <Sparkles className="w-3.5 h-3.5 text-blue-600 absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 animate-pulse" />
          </div>
          <span className="text-[10px] font-bold font-mono text-slate-600 uppercase tracking-wider animate-pulse">
            Consulting Gemini Engine...
          </span>
        </div>
      )}
    </div>
  );
}
