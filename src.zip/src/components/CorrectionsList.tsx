import React from 'react';
import { TextError } from '../types';
import { Sparkles, Trash2, Check, ArrowRight, ShieldAlert, BookPlus, AlertCircle, HelpCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface CorrectionsListProps {
  errors: TextError[];
  onApply: (error: TextError, suggestion: string) => void;
  onIgnore: (error: TextError) => void;
  onAddToDictionary: (word: string) => void;
  activeErrorId: string | null;
  onSelectError: (id: string | null) => void;
}

export const CorrectionsList: React.FC<CorrectionsListProps> = ({
  errors,
  onApply,
  onIgnore,
  onAddToDictionary,
  activeErrorId,
  onSelectError
}) => {
  const getBadgeStyle = (type: string) => {
    switch (type) {
      case 'spelling':
        return 'bg-rose-50 text-rose-700 border-rose-100';
      case 'capitalization':
        return 'bg-amber-50 text-amber-700 border-amber-100';
      case 'punctuation':
        return 'bg-blue-50 text-blue-700 border-blue-100';
      case 'style':
        return 'bg-emerald-50 text-emerald-700 border-emerald-100';
      default:
        return 'bg-blue-50 text-blue-700 border-blue-100';
    }
  };

  const getLabel = (type: string) => {
    switch (type) {
      case 'spelling': return 'Spelling Mistake';
      case 'capitalization': return 'Capitalization';
      case 'punctuation': return 'Punctuation';
      case 'style': return 'Style/Redundancy';
      default: return 'Grammar';
    }
  };

  if (errors.length === 0) {
    return (
      <div className="bg-white rounded-lg border border-slate-200 p-6 text-center flex flex-col items-center justify-center space-y-3 shadow-sm min-h-[300px]">
        <div className="w-10 h-10 rounded-full bg-emerald-50 border border-emerald-100 flex items-center justify-center text-emerald-500">
          <Check className="w-5 h-5 stroke-[3]" />
        </div>
        <div className="space-y-1">
          <h4 className="font-display font-bold text-slate-800 text-sm">Perfect Writing!</h4>
          <p className="text-xs text-slate-400 max-w-xs leading-relaxed">
            No spelling or grammatical issues found. Your document is clear and polished!
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-2.5">
      <div className="flex items-center justify-between px-1">
        <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">
          Active Problems ({errors.length})
        </span>
        <span className="text-[9px] text-blue-600 font-bold font-mono uppercase tracking-wider">CLICK WORD TO FOCUS</span>
      </div>

      <div className="space-y-2 max-h-[600px] overflow-y-auto custom-scrollbar pr-0.5">
        <AnimatePresence initial={false}>
          {errors.map((err) => {
            const isActive = activeErrorId === err.id;

            return (
              <motion.div
                key={err.id}
                id={`card-${err.id}`}
                layout
                initial={{ opacity: 0, y: 15 }}
                animate={{
                  opacity: 1,
                  y: 0,
                  scale: isActive ? 1.01 : 1,
                  borderColor: isActive ? '#2563eb' : '#e2e8f0'
                }}
                exit={{ opacity: 0, scale: 0.9, transition: { duration: 0.15 } }}
                className={`bg-white rounded-lg border p-3.5 space-y-2.5 cursor-pointer shadow-xs transition-all hover:shadow-sm ${
                  isActive ? 'ring-2 ring-blue-100 border-blue-600' : 'border-slate-200'
                }`}
                onClick={() => onSelectError(isActive ? null : err.id)}
              >
                {/* Header Row */}
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <span className={`px-1.5 py-0.5 rounded text-[9px] font-bold border uppercase tracking-wider ${getBadgeStyle(err.type)}`}>
                      {getLabel(err.type)}
                    </span>
                  </div>
                  <span className="text-[9px] text-slate-400 font-mono">INDEX {err.index}</span>
                </div>

                {/* Phrase Change Row */}
                <div className="flex items-center flex-wrap gap-2 py-0.5">
                  <span className="px-1.5 py-0.5 rounded bg-rose-50 text-rose-800 line-through font-bold text-xs border border-rose-100 max-w-[150px] truncate">
                    {err.word}
                  </span>
                  <ArrowRight className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                  {err.suggestions.length > 0 ? (
                    <span className="px-1.5 py-0.5 rounded bg-emerald-50 text-emerald-800 font-bold text-xs border border-emerald-100 shrink-0">
                      {err.suggestions[0]}
                    </span>
                  ) : (
                    <span className="text-[10px] text-slate-400 italic">No direct substitution</span>
                  )}
                </div>

                {/* Main description message */}
                <p className="text-xs text-slate-700 font-semibold leading-relaxed">
                  {err.message}
                </p>

                {/* Expand details when active */}
                {isActive && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    className="pt-2.5 border-t border-slate-100 space-y-2.5"
                  >
                    {/* Grammar Rule explanation */}
                    {err.type !== 'spelling' && (err as any).explanation && (
                      <div className="bg-slate-50 rounded p-2.5 text-[10px] text-slate-600 flex items-start gap-2 border border-slate-100 leading-relaxed">
                        <HelpCircle className="w-3.5 h-3.5 text-slate-400 shrink-0 mt-0.5" />
                        <div>{(err as any).explanation}</div>
                      </div>
                    )}

                    {/* Suggestion list buttons */}
                    <div className="space-y-1">
                      <div className="text-[10px] font-bold text-slate-400 flex items-center gap-1 uppercase tracking-wider">
                        <Sparkles className="w-2.5 h-2.5 text-blue-500" /> Suggestions (Ranked)
                      </div>
                      <div className="flex flex-wrap gap-1 pt-0.5">
                        {err.suggestions.map((sug, sIdx) => (
                          <button
                            key={sIdx}
                            onClick={(e) => {
                              e.stopPropagation();
                              onApply(err, sug);
                            }}
                            className="px-2 py-1 bg-blue-50 hover:bg-blue-100 text-blue-700 font-bold rounded text-[11px] transition border border-blue-100 flex items-center gap-1 cursor-pointer active:scale-95"
                          >
                            {sug}
                            {sIdx === 0 && <span className="text-[8px] bg-blue-200/50 px-1 py-0.5 rounded font-mono uppercase text-blue-800 ml-1">Best</span>}
                          </button>
                        ))}
                        {err.suggestions.length === 0 && (
                          <span className="text-[10px] text-slate-400 italic">No suggestions</span>
                        )}
                      </div>
                    </div>

                    {/* Operational Actions */}
                    <div className="flex items-center justify-between pt-0.5 gap-2">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onIgnore(err);
                        }}
                        className="px-2 py-1 text-slate-500 hover:text-slate-700 bg-slate-50 hover:bg-slate-100 rounded text-[10px] transition flex items-center gap-1 cursor-pointer"
                      >
                        <Trash2 className="w-3 h-3" /> Ignore
                      </button>

                      {err.type === 'spelling' && (
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            onAddToDictionary(err.word);
                          }}
                          className="px-2 py-1 text-blue-600 hover:text-blue-800 bg-blue-50/50 hover:bg-blue-50 rounded text-[10px] transition border border-blue-100/30 flex items-center gap-1 cursor-pointer font-bold"
                        >
                          <BookPlus className="w-3 h-3" /> Add Dict
                        </button>
                      )}
                    </div>
                  </motion.div>
                )}
              </motion.div>
            );
          })}
        </AnimatePresence>
      </div>
    </div>
  );
};
