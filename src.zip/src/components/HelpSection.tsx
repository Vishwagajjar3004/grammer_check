import React from 'react';
import { HelpCircle, CheckCircle2, XCircle } from 'lucide-react';

export const HelpSection: React.FC = () => {
  const rules = [
    {
      title: 'Spelling Lookups',
      description: 'Finds spelling errors using our custom BK-Tree. Suggestions are ranked by Levenshtein distance, word frequency, and length.',
      bad: 'He went to the schol.',
      good: 'He went to the school.'
    },
    {
      title: 'Indefinite Articles (A/An)',
      description: 'Checks article agreement based on vowel or consonant sounds, honoring silent letters and consonantal vowel sounds.',
      bad: 'She has a apple and an university degree.',
      good: 'She has an apple and a university degree.'
    },
    {
      title: 'Subject-Verb Agreement',
      description: 'Ensures nouns and pronouns match their auxiliary verbs (has/have, was/were, do/does) correctly.',
      bad: 'He have completed the task. They was sleeping.',
      good: 'He has completed the task. They were sleeping.'
    },
    {
      title: 'Passive Voice Warnings',
      description: 'Flags passive constructions that can be rewritten actively to increase readability and strength.',
      bad: 'The code was written by Vishwa.',
      good: 'Vishwa wrote the code.'
    },
    {
      title: 'Sentence Capitalization',
      description: 'Asserts that the first letter of any sentence must be capitalised.',
      bad: 'this is a sentence. and another.',
      good: 'This is a sentence. And another.'
    }
  ];

  return (
    <div className="bg-white rounded-lg border border-slate-200 shadow-sm p-4 space-y-3.5 flex-1 flex flex-col">
      <h3 className="text-[11px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2">
        <HelpCircle className="w-4 h-4 text-blue-600" />
        Grammar Rules Guide
      </h3>
      <p className="text-[10px] text-slate-500 leading-relaxed">
        Our local checking engine operates completely offline using a compiled vocabulary catalog and regex heuristics. It validates the following:
      </p>

      <div className="space-y-3 max-h-[350px] overflow-y-auto custom-scrollbar pr-0.5 flex-1">
        {rules.map((r, i) => (
          <div key={i} className="p-2.5 bg-slate-50/50 rounded border border-slate-150 space-y-1.5">
            <h4 className="text-[11px] font-bold text-slate-700 uppercase tracking-wide">{r.title}</h4>
            <p className="text-[10px] text-slate-500 leading-relaxed">{r.description}</p>
            <div className="grid grid-cols-2 gap-2 pt-0.5 text-[9px] font-mono">
              <div className="flex items-start gap-1 p-1 bg-rose-50 border border-rose-100 rounded text-rose-700">
                <XCircle className="w-3 h-3 shrink-0 mt-0.5 text-rose-500" />
                <span className="italic leading-tight">{r.bad}</span>
              </div>
              <div className="flex items-start gap-1 p-1 bg-emerald-50 border border-emerald-100 rounded text-emerald-700 font-semibold">
                <CheckCircle2 className="w-3 h-3 shrink-0 mt-0.5 text-emerald-500" />
                <span className="leading-tight">{r.good}</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
