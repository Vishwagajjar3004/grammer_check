import React from 'react';
import { DocumentStats } from '../types';
import { FileText, Type, Clock, ShieldAlert, BadgeCheck, Activity } from 'lucide-react';

interface StatsPanelProps {
  stats: DocumentStats;
}

export const StatsPanel: React.FC<StatsPanelProps> = ({ stats }) => {
  // Determine color for the circular progress based on score
  const getScoreColor = (score: number) => {
    if (score >= 90) return 'text-emerald-500 stroke-emerald-500';
    if (score >= 75) return 'text-amber-500 stroke-amber-500';
    return 'text-rose-500 stroke-rose-500';
  };

  const getScoreBgColor = (score: number) => {
    if (score >= 90) return 'bg-emerald-50 text-emerald-700 border-emerald-100';
    if (score >= 75) return 'bg-amber-50 text-amber-700 border-amber-100';
    return 'bg-rose-50 text-rose-700 border-rose-100';
  };

  const getScoreLabel = (score: number) => {
    if (score >= 90) return 'Excellent';
    if (score >= 75) return 'Very Good';
    if (score === 100) return 'Flawless';
    return 'Needs Review';
  };

  // SVG Circular progress math
  const radius = 36;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (stats.score / 100) * circumference;

  return (
    <div className="bg-white rounded-lg border border-slate-200 shadow-sm p-4 space-y-4 flex-1">
      <div className="flex items-center justify-between">
        <h3 className="text-[11px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2">
          <Activity className="w-4 h-4 text-blue-600 animate-pulse" />
          Document Health
        </h3>
        <span className="text-[10px] font-mono text-slate-400">REAL-TIME</span>
      </div>

      {/* Circle Score Indicator */}
      <div className="flex items-center gap-4 bg-slate-50/50 p-3 rounded border border-slate-100">
        <div className="relative flex items-center justify-center w-16 h-16 shrink-0">
          <svg className="w-full h-full transform -rotate-90">
            {/* Background ring */}
            <circle
              cx="32"
              cy="32"
              r={radius - 4}
              className="stroke-slate-200"
              strokeWidth="5"
              fill="transparent"
            />
            {/* Foreground progress */}
            <circle
              cx="32"
              cy="32"
              r={radius - 4}
              className={`transition-all duration-500 ease-out ${getScoreColor(stats.score)}`}
              strokeWidth="5"
              strokeDasharray={circumference - 25}
              strokeDashoffset={strokeDashoffset * 0.8}
              strokeLinecap="round"
              fill="transparent"
            />
          </svg>
          <div className="absolute font-mono font-bold text-slate-800 text-sm">
            {stats.score}%
          </div>
        </div>

        <div className="space-y-0.5">
          <div className="text-[10px] font-semibold uppercase tracking-wider text-slate-400">Quality Score</div>
          <div className={`px-2 py-0.5 rounded text-[10px] font-medium border inline-block ${getScoreBgColor(stats.score)}`}>
            {getScoreLabel(stats.score)}
          </div>
          <p className="text-[10px] text-slate-500 leading-snug">
            {stats.score >= 90
              ? 'Your writing is clear, polished, and ready.'
              : stats.score >= 75
              ? 'A few adjustments can make this stronger.'
              : 'Several issues need attention.'}
          </p>
        </div>
      </div>

      {/* Grid of details */}
      <div className="grid grid-cols-2 gap-2">
        <div className="p-2.5 bg-white border border-slate-150 rounded space-y-0.5">
          <div className="flex items-center gap-1.5 text-slate-400">
            <FileText className="w-3 h-3 text-slate-500" />
            <span className="text-[10px] text-slate-500 font-semibold uppercase tracking-wider">Words</span>
          </div>
          <div className="font-mono font-bold text-base text-slate-800">{stats.words}</div>
        </div>

        <div className="p-2.5 bg-white border border-slate-150 rounded space-y-0.5">
          <div className="flex items-center gap-1.5 text-slate-400">
            <Type className="w-3 h-3 text-slate-500" />
            <span className="text-[10px] text-slate-500 font-semibold uppercase tracking-wider">Chars</span>
          </div>
          <div className="font-mono font-bold text-base text-slate-800">{stats.chars}</div>
        </div>

        <div className="p-2.5 bg-white border border-slate-150 rounded space-y-0.5">
          <div className="flex items-center gap-1.5 text-slate-400">
            <Clock className="w-3 h-3 text-slate-500" />
            <span className="text-[10px] text-slate-500 font-semibold uppercase tracking-wider">Read Time</span>
          </div>
          <div className="font-mono font-bold text-base text-slate-800">{stats.readingTime} min</div>
        </div>

        <div className="p-2.5 bg-white border border-slate-150 rounded space-y-0.5">
          <div className="flex items-center gap-1.5 text-slate-400">
            <BadgeCheck className="w-3 h-3 text-slate-500" />
            <span className="text-[10px] text-slate-500 font-semibold uppercase tracking-wider">Sentences</span>
          </div>
          <div className="font-mono font-bold text-base text-slate-800">{stats.sentences}</div>
        </div>
      </div>

      {/* Issue Summary Breakdown */}
      <div className="space-y-2 pt-2 border-t border-slate-200 text-[11px]">
        <div className="flex justify-between items-center">
          <span className="text-slate-500 font-medium">Spelling Issues</span>
          <span className={`px-2 py-0.5 rounded font-mono font-bold ${stats.spellingErrors > 0 ? 'bg-rose-50 text-rose-600 border border-rose-100' : 'bg-slate-50 text-slate-400'}`}>
            {stats.spellingErrors}
          </span>
        </div>

        <div className="flex justify-between items-center">
          <span className="text-slate-500 font-medium">Grammar & Style Issues</span>
          <span className={`px-2 py-0.5 rounded font-mono font-bold ${stats.grammarErrors > 0 ? 'bg-blue-50 text-blue-600 border border-blue-100' : 'bg-slate-50 text-slate-400'}`}>
            {stats.grammarErrors}
          </span>
        </div>

        <div className="flex justify-between items-center font-bold text-slate-700 pt-1.5 border-t border-slate-100">
          <span className="uppercase tracking-wide text-[10px]">Total Corrections</span>
          <span className={`px-2 py-0.5 rounded font-mono ${stats.spellingErrors + stats.grammarErrors > 0 ? 'bg-amber-50 text-amber-600 border border-amber-100' : 'bg-emerald-50 text-emerald-600 border border-emerald-100'}`}>
            {stats.spellingErrors + stats.grammarErrors}
          </span>
        </div>
      </div>
    </div>
  );
};
